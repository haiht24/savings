<?php

// store post type

load_template(trailingslashit(get_template_directory()) . '/inc/custom-post-type/store_post_type.php');

// coupon post type

load_template(trailingslashit(get_template_directory()).'/inc/custom-post-type/coupon_post_type.php');
?>
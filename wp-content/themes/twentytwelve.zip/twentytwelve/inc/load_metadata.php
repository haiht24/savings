<?php
// store category metadata
include_once('metadata/store_category_metadata.php');
// store metadata
include_once('metadata/store_metadata.php');
// coupon metadata
include_once('metadata/coupon_metadata.php');
?>
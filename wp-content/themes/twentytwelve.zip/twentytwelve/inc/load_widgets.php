<?php
	// Random category
	include_once ('widgets/wg_random_category.php');
    // Top View Stores
    include_once ('widgets/wg_top_view_stores.php');
    // Store Type Off
    include_once ('widgets/wg_type_off.php');
    // Related Stores
    include_once ('widgets/wg_related_stores.php');

?>